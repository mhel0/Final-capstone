import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Send, User, MessageCircle } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface Message {
  id: string;
  senderId: string;
  message: string;
  isAdminMessage: boolean;
  isRead?: boolean;
  createdAt: string;
}

export function AdminChat() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [isConnected, setIsConnected] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const wsRef = useRef<WebSocket | null>(null);

  const { data: allMessages = [] } = useQuery<Message[]>({
    queryKey: ["/api/chat/messages"],
    refetchInterval: 5000, // Fallback polling every 5 seconds
  });

  // Group messages by customer
  const customerMessages = allMessages.reduce((acc, message) => {
    const customerId = message.isAdminMessage ? message.senderId : message.senderId;
    if (!acc[customerId]) {
      acc[customerId] = [];
    }
    acc[customerId].push(message);
    return acc;
  }, {} as Record<string, Message[]>);

  const customers = Object.keys(customerMessages).filter(id => id !== user?.id);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (user) {
      // Connect to WebSocket
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      try {
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = () => {
          setIsConnected(true);
          // Authenticate WebSocket connection
          ws.send(JSON.stringify({
            type: 'auth',
            userId: user.id,
            userRole: user.role,
          }));
        };

        ws.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);
            if (data.type === 'new_message') {
              setMessages(prev => [...prev, data.data]);
            }
          } catch (error) {
            console.error('Failed to parse WebSocket message:', error);
          }
        };

        ws.onclose = () => {
          setIsConnected(false);
        };

        ws.onerror = (error) => {
          console.error('WebSocket error:', error);
          setIsConnected(false);
          toast({
            title: "Connection Error",
            description: "Failed to connect to chat. Please try again.",
            variant: "destructive",
          });
        };

        return () => {
          ws.close();
        };
      } catch (error) {
        console.error('Failed to create WebSocket connection:', error);
        toast({
          title: "Connection Error",
          description: "Failed to connect to chat. Please try again.",
          variant: "destructive",
        });
      }
    }
  }, [user]);

  // Update messages when selectedCustomer changes
  useEffect(() => {
    if (selectedCustomer) {
      setMessages(customerMessages[selectedCustomer] || []);
    }
  }, [selectedCustomer, allMessages]);

  const sendMessage = () => {
    if (!newMessage.trim() || !wsRef.current || !user || !selectedCustomer) return;

    const messageData = {
      message: newMessage.trim(),
      receiverId: selectedCustomer,
    };

    if (wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'chat_message',
        message: messageData,
      }));
      
      setNewMessage("");
    } else {
      toast({
        title: "Connection Error",
        description: "Chat is not connected. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="grid lg:grid-cols-3 gap-6 h-[600px]">
      {/* Customer List */}
      <Card className="rounded-2xl shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageCircle className="h-5 w-5" />
            Customer Chats
            <div className="flex items-center gap-2 ml-auto">
              <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`} />
              <span className="text-xs text-muted-foreground">
                {isConnected ? 'Connected' : 'Disconnected'}
              </span>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {customers.length === 0 ? (
            <div className="text-center py-8">
              <MessageCircle className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground">No active chats</p>
              <p className="text-sm text-muted-foreground">Customer messages will appear here</p>
            </div>
          ) : (
            <div className="space-y-2">
              {customers.map((customerId) => {
                const customerMsgs = customerMessages[customerId] || [];
                const lastMessage = customerMsgs[customerMsgs.length - 1];
                const unreadCount = customerMsgs.filter(msg => !msg.isAdminMessage && !msg.isRead).length;
                
                return (
                  <Button
                    key={customerId}
                    variant={selectedCustomer === customerId ? "default" : "outline"}
                    className="w-full text-left p-4 h-auto rounded-xl justify-start"
                    onClick={() => setSelectedCustomer(customerId)}
                    data-testid={`button-customer-${customerId}`}
                  >
                    <div className="flex items-center gap-3 w-full">
                      <div className="w-10 h-10 bg-gray-300 dark:bg-gray-600 rounded-full flex items-center justify-center">
                        <User className="h-5 w-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">Customer {customerId.slice(0, 8)}</p>
                        {lastMessage && (
                          <p className="text-xs text-muted-foreground truncate">
                            {lastMessage.message}
                          </p>
                        )}
                      </div>
                      {unreadCount > 0 && (
                        <Badge className="bg-red-500 text-white">
                          {unreadCount}
                        </Badge>
                      )}
                    </div>
                  </Button>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Chat Area */}
      <Card className="lg:col-span-2 rounded-2xl shadow-sm flex flex-col">
        {selectedCustomer ? (
          <>
            {/* Chat Header */}
            <CardHeader className="border-b">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gray-300 dark:bg-gray-600 rounded-full flex items-center justify-center">
                  <User className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-medium">Customer {selectedCustomer.slice(0, 8)}</p>
                  <p className="text-sm text-green-600">Online</p>
                </div>
              </div>
            </CardHeader>
            
            {/* Messages */}
            <CardContent className="flex-1 overflow-y-auto p-4">
              <div className="space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex gap-3 ${message.isAdminMessage ? 'justify-end' : ''}`}
                    data-testid={`admin-message-${message.id}`}
                  >
                    {!message.isAdminMessage && (
                      <div className="w-8 h-8 bg-gray-300 dark:bg-gray-600 rounded-full flex items-center justify-center flex-shrink-0">
                        <User className="h-4 w-4" />
                      </div>
                    )}
                    <div
                      className={`max-w-xs rounded-2xl p-3 ${
                        message.isAdminMessage
                          ? 'bg-primary text-primary-foreground rounded-tr-md'
                          : 'bg-gray-100 dark:bg-gray-800 rounded-tl-md'
                      }`}
                    >
                      <p className="text-sm">{message.message}</p>
                      <p className="text-xs opacity-70 mt-1">
                        {new Date(message.createdAt).toLocaleTimeString()}
                      </p>
                    </div>
                    {message.isAdminMessage && (
                      <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-white text-xs font-medium">A</span>
                      </div>
                    )}
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
            </CardContent>
            
            {/* Chat Input */}
            <div className="p-4 border-t">
              <div className="flex gap-2">
                <Input
                  placeholder="Type a message..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  className="rounded-xl"
                  disabled={!isConnected}
                  data-testid="input-admin-chat-message"
                />
                <Button
                  onClick={sendMessage}
                  disabled={!newMessage.trim() || !isConnected}
                  className="rounded-xl"
                  data-testid="button-send-admin-message"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </>
        ) : (
          <CardContent className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <MessageCircle className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground">Select a customer to start chatting</p>
            </div>
          </CardContent>
        )}
      </Card>
    </div>
  );
}
