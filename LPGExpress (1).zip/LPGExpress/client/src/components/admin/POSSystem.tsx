import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { 
  Plus, Minus, Trash2, CreditCard, Receipt, 
  ShoppingCart, Package, Calculator 
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface Product {
  id: string;
  name: string;
  weight: number;
  option: string;
  price: string;
  stock: number;
}

interface POSItem {
  productId: string;
  name: string;
  price: number;
  quantity: number;
  stock: number;
}

export function POSSystem() {
  const [posItems, setPosItems] = useState<POSItem[]>([]);
  const [customerInfo, setCustomerInfo] = useState({
    name: "",
    phone: "",
    address: "",
  });
  const [paymentMethod, setPaymentMethod] = useState("cod");
  const [notes, setNotes] = useState("");

  const queryClient = useQueryClient();

  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const createOrderMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/orders", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      toast({
        title: "Order Processed",
        description: "Order has been created successfully.",
      });
      resetPOS();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to process order. Please try again.",
        variant: "destructive",
      });
    },
  });

  const addToPos = (product: Product) => {
    if (product.stock <= 0) {
      toast({
        title: "Out of Stock",
        description: "This product is currently out of stock.",
        variant: "destructive",
      });
      return;
    }

    const existingItem = posItems.find(item => item.productId === product.id);
    
    if (existingItem) {
      if (existingItem.quantity >= product.stock) {
        toast({
          title: "Insufficient Stock",
          description: "Cannot add more items than available stock.",
          variant: "destructive",
        });
        return;
      }
      
      setPosItems(items =>
        items.map(item =>
          item.productId === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      );
    } else {
      setPosItems(items => [
        ...items,
        {
          productId: product.id,
          name: product.name,
          price: parseFloat(product.price),
          quantity: 1,
          stock: product.stock,
        },
      ]);
    }
  };

  const updateQuantity = (productId: string, newQuantity: number) => {
    if (newQuantity === 0) {
      setPosItems(items => items.filter(item => item.productId !== productId));
    } else {
      const item = posItems.find(item => item.productId === productId);
      if (item && newQuantity > item.stock) {
        toast({
          title: "Insufficient Stock",
          description: "Cannot add more items than available stock.",
          variant: "destructive",
        });
        return;
      }
      
      setPosItems(items =>
        items.map(item =>
          item.productId === productId
            ? { ...item, quantity: newQuantity }
            : item
        )
      );
    }
  };

  const removeItem = (productId: string) => {
    setPosItems(items => items.filter(item => item.productId !== productId));
  };

  const resetPOS = () => {
    setPosItems([]);
    setCustomerInfo({ name: "", phone: "", address: "" });
    setPaymentMethod("cod");
    setNotes("");
  };

  const subtotal = posItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const total = subtotal; // Add tax/fees if needed

  const handleProcessPayment = () => {
    if (posItems.length === 0) {
      toast({
        title: "Empty Cart",
        description: "Please add items to process payment.",
        variant: "destructive",
      });
      return;
    }

    if (!customerInfo.name || !customerInfo.address) {
      toast({
        title: "Missing Information",
        description: "Please fill in customer name and address.",
        variant: "destructive",
      });
      return;
    }

    const orderData = {
      userId: "pos-customer", // Special user ID for POS orders
      total: total.toString(),
      paymentMethod,
      deliveryAddress: {
        name: customerInfo.name,
        phone: customerInfo.phone,
        address: customerInfo.address,
      },
      notes,
      items: posItems.map(item => ({
        productId: item.productId,
        quantity: item.quantity,
        price: item.price.toString(),
      })),
    };

    createOrderMutation.mutate(orderData);
  };

  if (isLoading) {
    return (
      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="animate-pulse">
          <CardContent className="p-6">
            <div className="h-64 bg-gray-200 dark:bg-gray-700 rounded"></div>
          </CardContent>
        </Card>
        <Card className="animate-pulse">
          <CardContent className="p-6">
            <div className="h-64 bg-gray-200 dark:bg-gray-700 rounded"></div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      {/* POS Interface */}
      <Card className="rounded-2xl shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShoppingCart className="h-5 w-5" />
            Point of Sale
          </CardTitle>
        </CardHeader>
        <CardContent>
          {posItems.length === 0 ? (
            <div className="text-center py-8">
              <Calculator className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground">No items in cart</p>
              <p className="text-sm text-muted-foreground">Select products to start</p>
            </div>
          ) : (
            <>
              <div className="space-y-3 mb-4 max-h-64 overflow-y-auto">
                {posItems.map((item) => (
                  <div 
                    key={item.productId} 
                    className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-xl"
                    data-testid={`pos-item-${item.productId}`}
                  >
                    <div className="flex-1">
                      <p className="font-medium text-sm">{item.name}</p>
                      <p className="text-xs text-muted-foreground">
                        ₱{item.price} × {item.quantity}
                      </p>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-8 w-8 rounded-full"
                        onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                        data-testid={`button-decrease-pos-${item.productId}`}
                      >
                        <Minus className="h-3 w-3" />
                      </Button>
                      <span className="w-8 text-center text-sm">{item.quantity}</span>
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-8 w-8 rounded-full"
                        onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                        data-testid={`button-increase-pos-${item.productId}`}
                      >
                        <Plus className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-red-500"
                        onClick={() => removeItem(item.productId)}
                        data-testid={`button-remove-pos-${item.productId}`}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                    
                    <span className="font-semibold text-sm ml-2">
                      ₱{(item.price * item.quantity).toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>
              
              <Separator className="my-4" />
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Subtotal:</span>
                  <span>₱{subtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-lg font-bold">
                  <span>Total:</span>
                  <span data-testid="text-pos-total">₱{total.toLocaleString()}</span>
                </div>
              </div>
            </>
          )}
          
          {/* Customer Information */}
          <div className="mt-6 space-y-4">
            <h3 className="font-medium">Customer Information</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="customer-name">Name</Label>
                <Input
                  id="customer-name"
                  value={customerInfo.name}
                  onChange={(e) => setCustomerInfo({ ...customerInfo, name: e.target.value })}
                  placeholder="Customer name"
                  className="rounded-xl"
                  data-testid="input-customer-name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="customer-phone">Phone</Label>
                <Input
                  id="customer-phone"
                  value={customerInfo.phone}
                  onChange={(e) => setCustomerInfo({ ...customerInfo, phone: e.target.value })}
                  placeholder="Phone number"
                  className="rounded-xl"
                  data-testid="input-customer-phone"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="customer-address">Address</Label>
              <Textarea
                id="customer-address"
                value={customerInfo.address}
                onChange={(e) => setCustomerInfo({ ...customerInfo, address: e.target.value })}
                placeholder="Delivery address"
                className="rounded-xl"
                data-testid="input-customer-address"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="payment-method">Payment Method</Label>
              <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                <SelectTrigger className="rounded-xl" data-testid="select-pos-payment">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cod">Cash on Delivery</SelectItem>
                  <SelectItem value="cash">Cash Payment</SelectItem>
                  <SelectItem value="gcash">GCash</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Notes (Optional)</Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Special instructions"
                className="rounded-xl"
                data-testid="input-pos-notes"
              />
            </div>
          </div>
          
          <div className="flex gap-2 mt-6">
            <Button
              variant="outline"
              className="flex-1 rounded-xl"
              onClick={resetPOS}
              data-testid="button-clear-pos"
            >
              Clear All
            </Button>
            <Button
              className="flex-1 rounded-xl"
              onClick={handleProcessPayment}
              disabled={createOrderMutation.isPending}
              data-testid="button-process-payment"
            >
              <CreditCard className="h-4 w-4 mr-2" />
              Process Payment
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Product Grid */}
      <Card className="rounded-2xl shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            Products
          </CardTitle>
        </CardHeader>
        <CardContent>
          {products.length === 0 ? (
            <div className="text-center py-8">
              <Package className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground">No products available</p>
              <p className="text-sm text-muted-foreground">Add products in Product Management</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-96 overflow-y-auto">
              {products.map((product) => (
                <Button
                  key={product.id}
                  variant="outline"
                  className="p-4 h-auto rounded-xl text-left hover:bg-gray-100 dark:hover:bg-gray-800 transition-all"
                  onClick={() => addToPos(product)}
                  disabled={product.stock <= 0}
                  data-testid={`button-add-pos-${product.id}`}
                >
                  <div className="w-full">
                    <div className="flex items-center justify-between mb-2">
                      <p className="font-medium text-sm">{product.name}</p>
                      <Badge variant="secondary" className="text-xs">
                        {product.weight}kg
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <p className="text-primary font-semibold">₱{product.price}</p>
                      <p className="text-xs text-muted-foreground">
                        Stock: {product.stock}
                      </p>
                    </div>
                    {product.stock <= 0 && (
                      <p className="text-xs text-red-500 mt-1">Out of Stock</p>
                    )}
                  </div>
                </Button>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
