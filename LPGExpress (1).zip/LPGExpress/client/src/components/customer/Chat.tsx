import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Send, ShieldQuestion } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface Message {
  id: string;
  senderId: string;
  message: string;
  isAdminMessage: boolean;
  createdAt: string;
}

interface ChatProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function Chat({ open, onOpenChange }: ChatProps) {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      senderId: "admin",
      message: "Hello! How can I help you with your LPG delivery today?",
      isAdminMessage: true,
      createdAt: new Date().toISOString(),
    },
  ]);
  const [newMessage, setNewMessage] = useState("");
  const [isConnected, setIsConnected] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const wsRef = useRef<WebSocket | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (open && user) {
      // Connect to WebSocket
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      try {
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = () => {
          setIsConnected(true);
          // Authenticate WebSocket connection
          ws.send(JSON.stringify({
            type: 'auth',
            userId: user.id,
            userRole: user.role,
          }));
        };

        ws.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);
            if (data.type === 'new_message') {
              setMessages(prev => [...prev, data.data]);
            }
          } catch (error) {
            console.error('Failed to parse WebSocket message:', error);
          }
        };

        ws.onclose = () => {
          setIsConnected(false);
        };

        ws.onerror = (error) => {
          console.error('WebSocket error:', error);
          setIsConnected(false);
          toast({
            title: "Connection Error",
            description: "Failed to connect to chat. Please try again.",
            variant: "destructive",
          });
        };

        return () => {
          ws.close();
        };
      } catch (error) {
        console.error('Failed to create WebSocket connection:', error);
        toast({
          title: "Connection Error",
          description: "Failed to connect to chat. Please try again.",
          variant: "destructive",
        });
      }
    }
  }, [open, user]);

  const sendMessage = () => {
    if (!newMessage.trim() || !wsRef.current || !user) return;

    const messageData = {
      message: newMessage.trim(),
      receiverId: null, // Admin will receive customer messages
    };

    if (wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'chat_message',
        message: messageData,
      }));
      
      setNewMessage("");
    } else {
      toast({
        title: "Connection Error",
        description: "Chat is not connected. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="bottom" className="h-[80vh] rounded-t-3xl">
        <SheetHeader>
          <div className="flex items-center justify-between">
            <SheetTitle>Chat with Admin</SheetTitle>
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`} />
              <span className="text-xs text-muted-foreground">
                {isConnected ? 'Connected' : 'Disconnected'}
              </span>
            </div>
          </div>
        </SheetHeader>
        
        <div className="flex flex-col h-full mt-6">
          {/* Chat Header */}
          <div className="p-4 border-b">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <ShieldQuestion className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="font-medium">Admin Support</p>
                <p className="text-sm text-green-600">Online</p>
              </div>
            </div>
          </div>
          
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${message.isAdminMessage ? '' : 'justify-end'}`}
                data-testid={`message-${message.id}`}
              >
                {message.isAdminMessage && (
                  <div className="w-8 h-8 bg-gray-300 dark:bg-gray-600 rounded-full flex items-center justify-center flex-shrink-0">
                    <ShieldQuestion className="h-4 w-4" />
                  </div>
                )}
                <div
                  className={`max-w-xs rounded-2xl p-3 ${
                    message.isAdminMessage
                      ? 'bg-gray-100 dark:bg-gray-800 rounded-tl-md'
                      : 'bg-primary text-primary-foreground rounded-tr-md'
                  }`}
                >
                  <p className="text-sm">{message.message}</p>
                </div>
                {!message.isAdminMessage && (
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-white text-xs font-medium">
                      {user?.name?.charAt(0).toUpperCase()}
                    </span>
                  </div>
                )}
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
          
          {/* Chat Input */}
          <div className="p-4 border-t">
            <div className="flex gap-2">
              <Input
                placeholder="Type a message..."
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                className="rounded-xl"
                disabled={!isConnected}
                data-testid="input-chat-message"
              />
              <Button
                onClick={sendMessage}
                disabled={!newMessage.trim() || !isConnected}
                className="rounded-xl"
                data-testid="button-send-message"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
