import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Flame, Bell, ShoppingCart, Search, Home, Package, 
  MessageCircle, User, RefreshCw, Plus 
} from "lucide-react";
import { Cart } from "./Cart";
import { Profile } from "./Profile";
import { Chat } from "./Chat";

interface CustomerLayoutProps {
  children: React.ReactNode;
}

export function CustomerLayout({ children }: CustomerLayoutProps) {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("home");
  const [showCart, setShowCart] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showChat, setShowChat] = useState(false);

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    if (tab === "cart") {
      setShowCart(true);
    } else if (tab === "profile") {
      setShowProfile(true);
    } else if (tab === "chat") {
      setShowChat(true);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Mobile Header */}
      <header className="bg-background shadow-sm border-b sticky top-0 z-40">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                <Flame className="text-white h-5 w-5" />
              </div>
              <div>
                <h1 className="font-bold text-lg">LPG Express</h1>
                <p className="text-xs text-muted-foreground">Manila, PH</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="icon"
                className="relative rounded-xl"
                data-testid="button-notifications"
              >
                <Bell className="h-5 w-5" />
                <Badge className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                  3
                </Badge>
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="relative rounded-xl"
                onClick={() => setShowCart(true)}
                data-testid="button-cart"
              >
                <ShoppingCart className="h-5 w-5" />
                <Badge className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs bg-primary">
                  2
                </Badge>
              </Button>
            </div>
          </div>
          
          {/* Search Bar */}
          <div className="mt-4 relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search LPG tanks..."
              className="pl-12 rounded-xl bg-gray-100 dark:bg-gray-800 border-0"
              data-testid="input-search"
            />
          </div>
        </div>
      </header>

      {/* Quick Actions */}
      <section className="p-4">
        <div className="grid grid-cols-2 gap-3">
          <Button
            className="bg-primary hover:bg-primary/90 p-4 h-auto rounded-2xl text-left flex flex-col items-start space-y-2"
            data-testid="button-tank-swap"
          >
            <RefreshCw className="h-6 w-6" />
            <div>
              <div className="font-medium">Tank Swap</div>
              <div className="text-xs opacity-80">Exchange empty tank</div>
            </div>
          </Button>
          <Button
            className="bg-green-600 hover:bg-green-700 p-4 h-auto rounded-2xl text-left flex flex-col items-start space-y-2"
            data-testid="button-new-tank"
          >
            <Plus className="h-6 w-6" />
            <div>
              <div className="font-medium">New Tank</div>
              <div className="text-xs opacity-80">Buy new LPG tank</div>
            </div>
          </Button>
        </div>
      </section>

      {/* Main Content */}
      <main className="pb-20">
        {children}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-background border-t px-4 py-2 z-40">
        <div className="flex justify-around">
          <Button
            variant={activeTab === "home" ? "default" : "ghost"}
            className="flex flex-col items-center gap-1 p-2 h-auto"
            onClick={() => setActiveTab("home")}
            data-testid="nav-home"
          >
            <Home className="h-5 w-5" />
            <span className="text-xs font-medium">Home</span>
          </Button>
          <Button
            variant={activeTab === "orders" ? "default" : "ghost"}
            className="flex flex-col items-center gap-1 p-2 h-auto"
            onClick={() => setActiveTab("orders")}
            data-testid="nav-orders"
          >
            <Package className="h-5 w-5" />
            <span className="text-xs">Orders</span>
          </Button>
          <Button
            variant={activeTab === "chat" ? "default" : "ghost"}
            className="flex flex-col items-center gap-1 p-2 h-auto relative"
            onClick={() => handleTabChange("chat")}
            data-testid="nav-chat"
          >
            <MessageCircle className="h-5 w-5" />
            <span className="text-xs">Chat</span>
            <Badge className="absolute -top-1 -right-1 h-4 w-4 rounded-full p-0 flex items-center justify-center text-xs">
              1
            </Badge>
          </Button>
          <Button
            variant={activeTab === "profile" ? "default" : "ghost"}
            className="flex flex-col items-center gap-1 p-2 h-auto"
            onClick={() => handleTabChange("profile")}
            data-testid="nav-profile"
          >
            <User className="h-5 w-5" />
            <span className="text-xs">Profile</span>
          </Button>
        </div>
      </nav>

      {/* Modals */}
      <Cart open={showCart} onOpenChange={setShowCart} />
      <Profile open={showProfile} onOpenChange={setShowProfile} />
      <Chat open={showChat} onOpenChange={setShowChat} />
    </div>
  );
}
