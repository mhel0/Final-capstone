import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface Product {
  id: string;
  name: string;
  weight: number;
  option: string;
  price: string;
  imageUrl?: string;
  stock: number;
}

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
}

export function ProductCard({ product, onAddToCart }: ProductCardProps) {
  const isOutOfStock = product.stock <= 0;
  
  return (
    <Card className="rounded-2xl shadow-sm border overflow-hidden hover:shadow-md transition-all">
      <div className="aspect-square bg-gray-100 dark:bg-gray-800">
        {product.imageUrl ? (
          <img
            src={product.imageUrl}
            alt={product.name}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <div className="w-16 h-20 bg-gray-300 dark:bg-gray-600 rounded-lg flex items-center justify-center">
              <span className="text-2xl">🔥</span>
            </div>
          </div>
        )}
      </div>
      
      <CardContent className="p-4">
        <h3 className="font-semibold text-sm mb-1" data-testid={`text-product-name-${product.id}`}>
          {product.name}
        </h3>
        <div className="flex items-center gap-2 mb-2">
          <Badge variant="secondary" className="text-xs">
            {product.option}
          </Badge>
          <Badge variant="outline" className="text-xs">
            {product.weight}kg
          </Badge>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-lg font-bold text-primary" data-testid={`text-price-${product.id}`}>
            ₱{product.price}
          </span>
          <Button
            size="sm"
            className="rounded-lg text-xs font-medium"
            onClick={() => onAddToCart(product)}
            disabled={isOutOfStock}
            data-testid={`button-add-to-cart-${product.id}`}
          >
            {isOutOfStock ? "Out of Stock" : "Add"}
          </Button>
        </div>
        {product.stock <= 5 && product.stock > 0 && (
          <p className="text-xs text-orange-500 mt-1">Only {product.stock} left!</p>
        )}
      </CardContent>
    </Card>
  );
}
