import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Card, CardContent } from "@/components/ui/card";
import { 
  MapPin, Receipt, Settings, LogOut, Edit, 
  Save, X, Plus, Trash2 
} from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface ProfileProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface Address {
  id: string;
  label: string;
  address: string;
  isDefault: boolean;
}

export function Profile({ open, onOpenChange }: ProfileProps) {
  const { user, logout } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [showAddresses, setShowAddresses] = useState(false);
  const [showOrders, setShowOrders] = useState(false);
  const [editedProfile, setEditedProfile] = useState({
    name: user?.name || "",
    email: user?.email || "",
    phone: user?.phone || "",
  });

  const [addresses, setAddresses] = useState<Address[]>([
    {
      id: "1",
      label: "Home",
      address: "123 Main St, Manila, Philippines",
      isDefault: true,
    },
  ]);

  const [newAddress, setNewAddress] = useState({ label: "", address: "" });
  const [isAddingAddress, setIsAddingAddress] = useState(false);

  const handleSaveProfile = () => {
    // TODO: Implement profile update API call
    toast({
      title: "Profile Updated",
      description: "Your profile has been updated successfully.",
    });
    setIsEditing(false);
  };

  const handleLogout = async () => {
    await logout();
    onOpenChange(false);
  };

  const handleAddAddress = () => {
    if (!newAddress.label || !newAddress.address) {
      toast({
        title: "Missing Information",
        description: "Please fill in both label and address",
        variant: "destructive",
      });
      return;
    }

    const address: Address = {
      id: Date.now().toString(),
      label: newAddress.label,
      address: newAddress.address,
      isDefault: addresses.length === 0,
    };

    setAddresses([...addresses, address]);
    setNewAddress({ label: "", address: "" });
    setIsAddingAddress(false);
    
    toast({
      title: "Address Added",
      description: "New delivery address has been added.",
    });
  };

  const removeAddress = (id: string) => {
    setAddresses(addresses.filter(addr => addr.id !== id));
    toast({
      title: "Address Removed",
      description: "Delivery address has been removed.",
    });
  };

  if (showAddresses) {
    return (
      <Sheet open={open} onOpenChange={onOpenChange}>
        <SheetContent side="bottom" className="h-[80vh] rounded-t-3xl">
          <SheetHeader>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowAddresses(false)}
                data-testid="button-back-from-addresses"
              >
                <X className="h-4 w-4" />
              </Button>
              <SheetTitle>Delivery Addresses</SheetTitle>
            </div>
          </SheetHeader>
          
          <div className="space-y-4 mt-6">
            {addresses.map(address => (
              <Card key={address.id}>
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-medium">{address.label}</h4>
                        {address.isDefault && (
                          <span className="text-xs bg-primary text-primary-foreground px-2 py-1 rounded">
                            Default
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{address.address}</p>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeAddress(address.id)}
                      className="text-red-500"
                      data-testid={`button-remove-address-${address.id}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
            
            {isAddingAddress ? (
              <Card>
                <CardContent className="p-4 space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="address-label">Address Label</Label>
                    <Input
                      id="address-label"
                      placeholder="e.g., Home, Office"
                      value={newAddress.label}
                      onChange={(e) => setNewAddress({ ...newAddress, label: e.target.value })}
                      className="rounded-xl"
                      data-testid="input-address-label"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="address-text">Address</Label>
                    <Textarea
                      id="address-text"
                      placeholder="Enter complete address"
                      value={newAddress.address}
                      onChange={(e) => setNewAddress({ ...newAddress, address: e.target.value })}
                      className="rounded-xl"
                      data-testid="input-address-text"
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      className="flex-1 rounded-xl"
                      onClick={() => setIsAddingAddress(false)}
                      data-testid="button-cancel-address"
                    >
                      Cancel
                    </Button>
                    <Button
                      className="flex-1 rounded-xl"
                      onClick={handleAddAddress}
                      data-testid="button-save-address"
                    >
                      Save Address
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Button
                variant="outline"
                className="w-full rounded-xl"
                onClick={() => setIsAddingAddress(true)}
                data-testid="button-add-address"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add New Address
              </Button>
            )}
          </div>
        </SheetContent>
      </Sheet>
    );
  }

  if (showOrders) {
    return (
      <Sheet open={open} onOpenChange={onOpenChange}>
        <SheetContent side="bottom" className="h-[80vh] rounded-t-3xl">
          <SheetHeader>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowOrders(false)}
                data-testid="button-back-from-orders"
              >
                <X className="h-4 w-4" />
              </Button>
              <SheetTitle>Order History</SheetTitle>
            </div>
          </SheetHeader>
          
          <div className="space-y-4 mt-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <span className="font-medium">Order #LPG-001</span>
                  <span className="px-3 py-1 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 rounded-full text-xs font-medium">
                    Delivered
                  </span>
                </div>
                <p className="text-sm text-muted-foreground mb-2">11kg LPG Tank (Swap)</p>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Dec 28, 2024</span>
                  <span className="font-semibold">₱850</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </SheetContent>
      </Sheet>
    );
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="bottom" className="h-[80vh] rounded-t-3xl">
        <SheetHeader>
          <SheetTitle>Profile</SheetTitle>
        </SheetHeader>
        
        <div className="space-y-6 mt-6">
          <div className="text-center">
            <div className="w-20 h-20 bg-primary rounded-full mx-auto mb-4 flex items-center justify-center">
              <span className="text-white text-2xl font-medium">
                {user?.name?.charAt(0).toUpperCase()}
              </span>
            </div>
            
            {isEditing ? (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    value={editedProfile.name}
                    onChange={(e) => setEditedProfile({ ...editedProfile, name: e.target.value })}
                    className="rounded-xl"
                    data-testid="input-profile-name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={editedProfile.email}
                    onChange={(e) => setEditedProfile({ ...editedProfile, email: e.target.value })}
                    className="rounded-xl"
                    data-testid="input-profile-email"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={editedProfile.phone}
                    onChange={(e) => setEditedProfile({ ...editedProfile, phone: e.target.value })}
                    className="rounded-xl"
                    data-testid="input-profile-phone"
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    className="flex-1 rounded-xl"
                    onClick={() => setIsEditing(false)}
                    data-testid="button-cancel-edit"
                  >
                    <X className="h-4 w-4 mr-2" />
                    Cancel
                  </Button>
                  <Button
                    className="flex-1 rounded-xl"
                    onClick={handleSaveProfile}
                    data-testid="button-save-profile"
                  >
                    <Save className="h-4 w-4 mr-2" />
                    Save
                  </Button>
                </div>
              </div>
            ) : (
              <>
                <h4 className="text-xl font-semibold">{user?.name}</h4>
                <p className="text-muted-foreground">{user?.email}</p>
                <Button
                  variant="outline"
                  className="mt-4 rounded-xl"
                  onClick={() => setIsEditing(true)}
                  data-testid="button-edit-profile"
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Edit Profile
                </Button>
              </>
            )}
          </div>
          
          {!isEditing && (
            <div className="space-y-4">
              <Button
                variant="outline"
                className="w-full text-left p-4 rounded-2xl h-auto"
                onClick={() => setShowAddresses(true)}
                data-testid="button-delivery-addresses"
              >
                <div className="flex items-center gap-3">
                  <MapPin className="h-5 w-5 text-muted-foreground" />
                  <span>Delivery Addresses</span>
                </div>
              </Button>
              
              <Button
                variant="outline"
                className="w-full text-left p-4 rounded-2xl h-auto"
                onClick={() => setShowOrders(true)}
                data-testid="button-order-history"
              >
                <div className="flex items-center gap-3">
                  <Receipt className="h-5 w-5 text-muted-foreground" />
                  <span>Order History</span>
                </div>
              </Button>
              
              <Button
                variant="outline"
                className="w-full text-left p-4 rounded-2xl h-auto"
                data-testid="button-settings"
              >
                <div className="flex items-center gap-3">
                  <Settings className="h-5 w-5 text-muted-foreground" />
                  <span>Settings</span>
                </div>
              </Button>
              
              <Button
                variant="outline"
                className="w-full text-left p-4 rounded-2xl h-auto text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900"
                onClick={handleLogout}
                data-testid="button-logout"
              >
                <div className="flex items-center gap-3">
                  <LogOut className="h-5 w-5" />
                  <span>Logout</span>
                </div>
              </Button>
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}
