// Note: Using Drizzle directly instead of Supabase client as per blueprint guidelines
export const supabaseUrl = process.env.VITE_SUPABASE_URL || '';
export const supabaseAnonKey = process.env.VITE_SUPABASE_ANON_KEY || '';

// Database connection is handled through the backend API
// All database operations go through the Express server routes
