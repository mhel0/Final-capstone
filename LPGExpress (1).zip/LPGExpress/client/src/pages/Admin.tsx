import { useState } from "react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Dashboard } from "@/components/admin/Dashboard";
import { ProductManagement } from "@/components/admin/ProductManagement";
import { OrderManagement } from "@/components/admin/OrderManagement";
import { POSSystem } from "@/components/admin/POSSystem";
import { AdminChat } from "@/components/admin/AdminChat";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { 
  BarChart3, Package, Receipt, ScanBarcode, MessageSquare 
} from "lucide-react";

export default function Admin() {
  const [activeTab, setActiveTab] = useState("dashboard");

  const tabs = [
    { id: "dashboard", label: "Dashboard", icon: BarChart3, component: Dashboard },
    { id: "products", label: "Products", icon: Package, component: ProductManagement },
    { id: "orders", label: "Orders", icon: Receipt, component: OrderManagement },
    { id: "pos", label: "POS", icon: ScanBarcode, component: POSSystem },
    { id: "chat", label: "Chat", icon: MessageSquare, component: AdminChat },
  ];

  const ActiveComponent = tabs.find(tab => tab.id === activeTab)?.component || Dashboard;

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        {/* Admin Header */}
        <AdminLayout>
          {/* Navigation Tabs */}
          <div className="bg-background border-b px-4 -mt-4 mb-4 sticky top-16 z-30">
            <div className="flex space-x-1 overflow-x-auto">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <Button
                    key={tab.id}
                    variant="ghost"
                    className={`px-4 py-3 text-sm font-medium whitespace-nowrap border-b-2 transition-colors ${
                      activeTab === tab.id
                        ? "border-primary text-primary"
                        : "border-transparent text-muted-foreground hover:text-foreground"
                    }`}
                    onClick={() => setActiveTab(tab.id)}
                    data-testid={`tab-${tab.id}`}
                  >
                    <Icon className="h-4 w-4 mr-2" />
                    {tab.label}
                  </Button>
                );
              })}
            </div>
          </div>

          {/* Active Tab Content */}
          <ActiveComponent />
        </AdminLayout>
      </div>
    </Layout>
  );
}
