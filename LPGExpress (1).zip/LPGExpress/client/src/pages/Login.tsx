import { LoginForm } from "@/components/auth/LoginForm";
import { Layout } from "@/components/Layout";

export default function Login() {
  return (
    <Layout>
      <LoginForm />
    </Layout>
  );
}
