# Overview

LPG Express is a modern e-commerce mobile web application for LPG (Liquefied Petroleum Gas) tank delivery services. The system features role-based authentication with Admin and Customer roles, real-time chat functionality, and comprehensive business management tools including POS (Point of Sale), inventory management, and analytics. Built as a full-stack TypeScript application with a React frontend and Express.js backend, the system provides a complete solution for LPG delivery businesses.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client-side application is built with React 18 and TypeScript, utilizing Vite as the build tool and development server. The architecture follows a component-based structure with:

**UI Framework**: Custom component system built on Radix UI primitives with Tailwind CSS for styling, following the shadcn/ui design system. This provides consistent, accessible components with dark mode support.

**State Management**: React Query (TanStack Query) handles server state management, caching, and synchronization. Local state is managed through React hooks with Context API for global state like authentication and theming.

**Routing**: Wouter provides lightweight client-side routing with role-based route protection.

**Real-time Communication**: WebSocket integration for live chat functionality between admins and customers.

## Backend Architecture
The server is built with Express.js and TypeScript, following a clean architecture pattern:

**API Design**: RESTful endpoints with session-based authentication using express-session middleware. Role-based access control protects admin-only routes.

**Database Layer**: Drizzle ORM provides type-safe database operations with PostgreSQL as the primary database. The schema is designed to support multi-tenant operations with role-based data access.

**Real-time Features**: WebSocket server integration for live chat functionality with session-based authentication.

**File Structure**: Modular organization with separation of concerns - routes, storage layer, and business logic are clearly separated.

## Data Storage Solutions
**Primary Database**: PostgreSQL with Neon as the hosted provider, chosen for its reliability and ACID compliance needed for e-commerce transactions.

**ORM**: Drizzle ORM provides type-safe database operations with excellent TypeScript integration and migration support.

**Session Storage**: PostgreSQL-based session storage using connect-pg-simple for scalability and persistence.

**Schema Design**: Comprehensive e-commerce schema including:
- User management with role-based access (admin/customer)
- Product catalog with inventory tracking
- Order management with status workflows
- Real-time chat message storage
- Analytics and reporting data structures
- Receipt generation and audit trails

## Authentication and Authorization
**Session-Based Authentication**: Traditional session management with secure HTTP-only cookies, providing CSRF protection and secure session handling.

**Role-Based Access Control**: Two-tier system with Admin and Customer roles, with middleware-based route protection ensuring proper access control.

**Default Admin Account**: Pre-configured admin credentials (admin/admin123) for initial system access.

**Security Measures**: Password hashing with bcrypt, secure session configuration, and environment-based secret management.

# External Dependencies

## Database and Infrastructure
- **Neon PostgreSQL**: Hosted PostgreSQL database service providing scalable, serverless database infrastructure
- **Drizzle Kit**: Database migration and schema management tool

## UI and Component Libraries
- **Radix UI**: Headless, accessible UI primitives providing the foundation for all interactive components
- **Tailwind CSS**: Utility-first CSS framework for consistent, responsive styling
- **Lucide React**: SVG icon library providing consistent iconography

## Development and Build Tools
- **Vite**: Fast build tool and development server with hot module replacement
- **TypeScript**: Type-safe development with comprehensive type checking
- **Replit Integration**: Development environment plugins for seamless Replit deployment

## Real-time Communication
- **WebSocket (ws)**: Native WebSocket implementation for real-time chat functionality
- **Express Session**: Session management with PostgreSQL storage backend

## Form Handling and Validation
- **React Hook Form**: Performant form library with minimal re-renders
- **Zod**: TypeScript-first schema validation library
- **@hookform/resolvers**: Validation resolver integration

## Styling and Animation
- **Class Variance Authority**: Type-safe variant management for component styling
- **clsx**: Conditional className utility
- **Tailwind Merge**: Intelligent Tailwind class merging

The system is designed to be deployment-ready on Replit with environment-based configuration and can scale horizontally as the business grows.