import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import bcrypt from "bcrypt";
import session from "express-session";
import { storage } from "./storage";
import { 
  insertUserSchema, insertProductSchema, insertOrderSchema, insertOrderItemSchema,
  insertChatMessageSchema, insertInventoryTransactionSchema, insertReceiptSchema,
  insertScheduledDeliverySchema
} from "@shared/schema";
import { z } from "zod";

// Session middleware setup
declare module "express-session" {
  interface SessionData {
    userId?: string;
    userRole?: string;
  }
}

const sessionMiddleware = session({
  secret: process.env.SESSION_SECRET || "lpg-express-secret-key",
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === "production",
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000, // 24 hours
  },
});

interface WebSocketWithSession extends WebSocket {
  userId?: string;
  userRole?: string;
}

export async function registerRoutes(app: Express): Promise<Server> {
  app.use(sessionMiddleware);

  // Middleware to check authentication
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Authentication required" });
    }
    next();
  };

  const requireAdmin = (req: any, res: any, next: any) => {
    if (!req.session.userId || req.session.userRole !== "admin") {
      return res.status(403).json({ message: "Admin access required" });
    }
    next();
  };

  // Auth routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      req.session.userId = user.id;
      req.session.userRole = user.role;

      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword });
    } catch (error) {
      res.status(500).json({ message: "Login failed" });
    }
  });

  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "Email already exists" });
      }

      const user = await storage.createUser(userData);
      
      req.session.userId = user.id;
      req.session.userRole = user.role;

      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      res.status(500).json({ message: "Registration failed" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Logout failed" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/me", requireAuth, async (req, res) => {
    try {
      const user = await storage.getUser(req.session.userId!);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword });
    } catch (error) {
      res.status(500).json({ message: "Failed to get user data" });
    }
  });

  // Product routes
  app.get("/api/products", async (req, res) => {
    try {
      const products = await storage.getAllProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  app.post("/api/products", requireAdmin, async (req, res) => {
    try {
      const productData = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(productData);
      res.json(product);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid product data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create product" });
    }
  });

  app.put("/api/products/:id", requireAdmin, async (req, res) => {
    try {
      const updates = req.body;
      const product = await storage.updateProduct(req.params.id, updates);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ message: "Failed to update product" });
    }
  });

  app.delete("/api/products/:id", requireAdmin, async (req, res) => {
    try {
      const success = await storage.deleteProduct(req.params.id);
      if (!success) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json({ message: "Product deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete product" });
    }
  });

  app.get("/api/products/low-stock", requireAdmin, async (req, res) => {
    try {
      const products = await storage.getLowStockProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch low stock products" });
    }
  });

  // Order routes
  app.get("/api/orders", requireAuth, async (req, res) => {
    try {
      let orders;
      if (req.session.userRole === "admin") {
        orders = await storage.getAllOrders();
      } else {
        orders = await storage.getOrdersByUser(req.session.userId!);
      }
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  app.get("/api/orders/:id", requireAuth, async (req, res) => {
    try {
      const order = await storage.getOrder(req.params.id);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      // Check if user can access this order
      if (req.session.userRole !== "admin" && order.userId !== req.session.userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const orderItems = await storage.getOrderItems(order.id);
      res.json({ ...order, items: orderItems });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch order" });
    }
  });

  app.post("/api/orders", requireAuth, async (req, res) => {
    try {
      const orderData = insertOrderSchema.extend({
        items: z.array(insertOrderItemSchema.omit({ orderId: true }))
      }).parse({
        ...req.body,
        userId: req.session.userId,
      });

      const { items, ...orderInfo } = orderData;
      const order = await storage.createOrder(orderInfo);

      // Create order items
      for (const item of items) {
        await storage.createOrderItem({ ...item, orderId: order.id });
        
        // Create inventory transaction
        await storage.createInventoryTransaction({
          productId: item.productId,
          type: "out",
          quantity: item.quantity,
          reason: "Order fulfillment",
          orderId: order.id,
        });
      }

      // Create receipt
      const receipt = await storage.createReceipt({
        orderId: order.id,
        receiptNumber: `RCP-${Date.now()}`,
        data: { order, items },
      });

      res.json({ order, receipt });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid order data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create order" });
    }
  });

  app.put("/api/orders/:id", requireAuth, async (req, res) => {
    try {
      const order = await storage.getOrder(req.params.id);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }

      // Check permissions
      if (req.session.userRole !== "admin" && order.userId !== req.session.userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      const updates = req.body;
      const updatedOrder = await storage.updateOrder(req.params.id, updates);
      res.json(updatedOrder);
    } catch (error) {
      res.status(500).json({ message: "Failed to update order" });
    }
  });

  // Chat routes
  app.get("/api/chat/messages", requireAuth, async (req, res) => {
    try {
      let messages;
      if (req.session.userRole === "admin") {
        messages = await storage.getChatMessages();
      } else {
        messages = await storage.getChatMessages(req.session.userId!);
      }
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.post("/api/chat/messages", requireAuth, async (req, res) => {
    try {
      const messageData = insertChatMessageSchema.parse({
        ...req.body,
        senderId: req.session.userId,
        isAdminMessage: req.session.userRole === "admin",
      });

      const message = await storage.createChatMessage(messageData);
      
      // Broadcast to WebSocket clients
      wss.clients.forEach((client: WebSocketWithSession) => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({
            type: "new_message",
            data: message,
          }));
        }
      });

      res.json(message);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid message data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to send message" });
    }
  });

  // Analytics routes (admin only)
  app.get("/api/analytics/sales", requireAdmin, async (req, res) => {
    try {
      const today = new Date();
      const dailySales = await storage.getDailySales(today);
      const topProducts = await storage.getTopProducts(5);
      const customerStats = await storage.getCustomerStats();
      const lowStockProducts = await storage.getLowStockProducts();

      res.json({
        dailySales,
        topProducts,
        customerStats,
        lowStockCount: lowStockProducts.length,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch analytics" });
    }
  });

  // Inventory routes
  app.get("/api/inventory/transactions", requireAdmin, async (req, res) => {
    try {
      const productId = req.query.productId as string;
      const transactions = await storage.getInventoryTransactions(productId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch inventory transactions" });
    }
  });

  app.post("/api/inventory/transactions", requireAdmin, async (req, res) => {
    try {
      const transactionData = insertInventoryTransactionSchema.parse(req.body);
      const transaction = await storage.createInventoryTransaction(transactionData);
      res.json(transaction);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid transaction data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create inventory transaction" });
    }
  });

  // Receipt routes
  app.get("/api/receipts/order/:orderId", requireAuth, async (req, res) => {
    try {
      const order = await storage.getOrder(req.params.orderId);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }

      // Check permissions
      if (req.session.userRole !== "admin" && order.userId !== req.session.userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      const receipt = await storage.getReceiptByOrder(req.params.orderId);
      if (!receipt) {
        return res.status(404).json({ message: "Receipt not found" });
      }

      res.json(receipt);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch receipt" });
    }
  });

  // Scheduled deliveries routes
  app.get("/api/scheduled-deliveries", requireAuth, async (req, res) => {
    try {
      const deliveries = await storage.getScheduledDeliveries(req.session.userId!);
      res.json(deliveries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch scheduled deliveries" });
    }
  });

  app.post("/api/scheduled-deliveries", requireAuth, async (req, res) => {
    try {
      const deliveryData = insertScheduledDeliverySchema.parse({
        ...req.body,
        userId: req.session.userId,
      });

      const delivery = await storage.createScheduledDelivery(deliveryData);
      res.json(delivery);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid delivery data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create scheduled delivery" });
    }
  });

  const httpServer = createServer(app);

  // WebSocket setup for real-time chat
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws: WebSocketWithSession, request) => {
    console.log('WebSocket connection established');

    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        if (data.type === 'auth') {
          // Authenticate WebSocket connection
          ws.userId = data.userId;
          ws.userRole = data.userRole;
        } else if (data.type === 'chat_message') {
          // Handle chat message through WebSocket
          const messageData = {
            ...data.message,
            senderId: ws.userId,
            isAdminMessage: ws.userRole === 'admin',
          };

          const chatMessage = await storage.createChatMessage(messageData);
          
          // Broadcast to all connected clients
          wss.clients.forEach((client: WebSocketWithSession) => {
            if (client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify({
                type: 'new_message',
                data: chatMessage,
              }));
            }
          });
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      console.log('WebSocket connection closed');
    });
  });

  return httpServer;
}
