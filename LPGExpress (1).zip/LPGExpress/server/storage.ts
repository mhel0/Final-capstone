import { drizzle } from "drizzle-orm/neon-http";
import { neon } from "@neondatabase/serverless";
import { eq, desc, and, sql, count, sum, asc } from "drizzle-orm";
import { 
  users, products, orders, orderItems, chatMessages, inventoryTransactions, receipts, scheduledDeliveries,
  type User, type InsertUser, type Product, type InsertProduct, type Order, type InsertOrder,
  type OrderItem, type InsertOrderItem, type ChatMessage, type InsertChatMessage,
  type InventoryTransaction, type InsertInventoryTransaction, type Receipt, type InsertReceipt,
  type ScheduledDelivery, type InsertScheduledDelivery
} from "@shared/schema";
import { randomUUID } from "crypto";
import bcrypt from "bcrypt";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) {
  throw new Error("DATABASE_URL environment variable is required");
}

const sql_client = neon(databaseUrl);
const db = drizzle(sql_client);

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<InsertUser>): Promise<User | undefined>;
  
  // Products
  getAllProducts(): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, updates: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: string): Promise<boolean>;
  getLowStockProducts(): Promise<Product[]>;
  
  // Orders
  getAllOrders(): Promise<Order[]>;
  getOrdersByUser(userId: string): Promise<Order[]>;
  getOrder(id: string): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: string, updates: Partial<InsertOrder>): Promise<Order | undefined>;
  getOrderItems(orderId: string): Promise<OrderItem[]>;
  createOrderItem(orderItem: InsertOrderItem): Promise<OrderItem>;
  
  // Chat
  getChatMessages(userId?: string): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  markMessagesAsRead(userId: string, isAdmin: boolean): Promise<void>;
  
  // Inventory
  createInventoryTransaction(transaction: InsertInventoryTransaction): Promise<InventoryTransaction>;
  getInventoryTransactions(productId?: string): Promise<InventoryTransaction[]>;
  
  // Receipts
  createReceipt(receipt: InsertReceipt): Promise<Receipt>;
  getReceiptByOrder(orderId: string): Promise<Receipt | undefined>;
  
  // Scheduled Deliveries
  getScheduledDeliveries(userId: string): Promise<ScheduledDelivery[]>;
  createScheduledDelivery(delivery: InsertScheduledDelivery): Promise<ScheduledDelivery>;
  updateScheduledDelivery(id: string, updates: Partial<InsertScheduledDelivery>): Promise<ScheduledDelivery | undefined>;
  
  // Analytics
  getDailySales(date: Date): Promise<{ total: number; count: number }>;
  getTopProducts(limit?: number): Promise<Array<Product & { totalSold: number }>>;
  getCustomerStats(): Promise<{ totalCustomers: number; activeCustomers: number }>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const hashedPassword = await bcrypt.hash(user.password, 10);
    const result = await db.insert(users).values({
      ...user,
      password: hashedPassword,
    }).returning();
    return result[0];
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<User | undefined> {
    if (updates.password) {
      updates.password = await bcrypt.hash(updates.password, 10);
    }
    const result = await db.update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  // Products
  async getAllProducts(): Promise<Product[]> {
    return await db.select().from(products).where(eq(products.isActive, true)).orderBy(asc(products.name));
  }

  async getProduct(id: string): Promise<Product | undefined> {
    const result = await db.select().from(products).where(eq(products.id, id)).limit(1);
    return result[0];
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const result = await db.insert(products).values({
      ...product,
      sku: product.sku || `LPG-${product.weight}KG-${Date.now()}`,
    }).returning();
    return result[0];
  }

  async updateProduct(id: string, updates: Partial<InsertProduct>): Promise<Product | undefined> {
    const result = await db.update(products)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(products.id, id))
      .returning();
    return result[0];
  }

  async deleteProduct(id: string): Promise<boolean> {
    const result = await db.update(products)
      .set({ isActive: false, updatedAt: new Date() })
      .where(eq(products.id, id))
      .returning();
    return result.length > 0;
  }

  async getLowStockProducts(): Promise<Product[]> {
    return await db.select().from(products)
      .where(and(
        eq(products.isActive, true),
        sql`${products.stock} <= ${products.lowStockThreshold}`
      ));
  }

  // Orders
  async getAllOrders(): Promise<Order[]> {
    return await db.select().from(orders).orderBy(desc(orders.createdAt));
  }

  async getOrdersByUser(userId: string): Promise<Order[]> {
    return await db.select().from(orders)
      .where(eq(orders.userId, userId))
      .orderBy(desc(orders.createdAt));
  }

  async getOrder(id: string): Promise<Order | undefined> {
    const result = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
    return result[0];
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const orderNumber = `LPG-${Date.now()}`;
    const result = await db.insert(orders).values({
      ...order,
      orderNumber,
    }).returning();
    return result[0];
  }

  async updateOrder(id: string, updates: Partial<InsertOrder>): Promise<Order | undefined> {
    const result = await db.update(orders)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(orders.id, id))
      .returning();
    return result[0];
  }

  async getOrderItems(orderId: string): Promise<OrderItem[]> {
    return await db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
  }

  async createOrderItem(orderItem: InsertOrderItem): Promise<OrderItem> {
    const result = await db.insert(orderItems).values(orderItem).returning();
    return result[0];
  }

  // Chat
  async getChatMessages(userId?: string): Promise<ChatMessage[]> {
    if (userId) {
      return await db.select().from(chatMessages)
        .where(eq(chatMessages.senderId, userId))
        .orderBy(asc(chatMessages.createdAt));
    }
    return await db.select().from(chatMessages).orderBy(asc(chatMessages.createdAt));
  }

  async createChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const result = await db.insert(chatMessages).values(message).returning();
    return result[0];
  }

  async markMessagesAsRead(userId: string, isAdmin: boolean): Promise<void> {
    if (isAdmin) {
      await db.update(chatMessages)
        .set({ isRead: true })
        .where(and(
          eq(chatMessages.senderId, userId),
          eq(chatMessages.isRead, false)
        ));
    } else {
      await db.update(chatMessages)
        .set({ isRead: true })
        .where(and(
          eq(chatMessages.isAdminMessage, true),
          eq(chatMessages.isRead, false)
        ));
    }
  }

  // Inventory
  async createInventoryTransaction(transaction: InsertInventoryTransaction): Promise<InventoryTransaction> {
    const result = await db.insert(inventoryTransactions).values(transaction).returning();
    
    // Update product stock
    const product = await this.getProduct(transaction.productId);
    if (product && product.stock !== null) {
      const newStock = transaction.type === 'in' 
        ? product.stock + transaction.quantity
        : product.stock - transaction.quantity;
      await this.updateProduct(transaction.productId, { stock: newStock });
    }
    
    return result[0];
  }

  async getInventoryTransactions(productId?: string): Promise<InventoryTransaction[]> {
    if (productId) {
      return await db.select().from(inventoryTransactions)
        .where(eq(inventoryTransactions.productId, productId))
        .orderBy(desc(inventoryTransactions.createdAt));
    }
    return await db.select().from(inventoryTransactions)
      .orderBy(desc(inventoryTransactions.createdAt));
  }

  // Receipts
  async createReceipt(receipt: InsertReceipt): Promise<Receipt> {
    const receiptNumber = `RCP-${Date.now()}`;
    const result = await db.insert(receipts).values({
      ...receipt,
      receiptNumber,
    }).returning();
    return result[0];
  }

  async getReceiptByOrder(orderId: string): Promise<Receipt | undefined> {
    const result = await db.select().from(receipts)
      .where(eq(receipts.orderId, orderId))
      .limit(1);
    return result[0];
  }

  // Scheduled Deliveries
  async getScheduledDeliveries(userId: string): Promise<ScheduledDelivery[]> {
    return await db.select().from(scheduledDeliveries)
      .where(and(
        eq(scheduledDeliveries.userId, userId),
        eq(scheduledDeliveries.isActive, true)
      ))
      .orderBy(asc(scheduledDeliveries.nextDelivery));
  }

  async createScheduledDelivery(delivery: InsertScheduledDelivery): Promise<ScheduledDelivery> {
    const result = await db.insert(scheduledDeliveries).values(delivery).returning();
    return result[0];
  }

  async updateScheduledDelivery(id: string, updates: Partial<InsertScheduledDelivery>): Promise<ScheduledDelivery | undefined> {
    const result = await db.update(scheduledDeliveries)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(scheduledDeliveries.id, id))
      .returning();
    return result[0];
  }

  // Analytics
  async getDailySales(date: Date): Promise<{ total: number; count: number }> {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);

    const result = await db.select({
      total: sum(orders.total),
      count: count(orders.id),
    }).from(orders)
      .where(and(
        sql`${orders.createdAt} >= ${startOfDay}`,
        sql`${orders.createdAt} <= ${endOfDay}`,
        eq(orders.status, 'delivered')
      ));

    return {
      total: Number(result[0]?.total || 0),
      count: Number(result[0]?.count || 0),
    };
  }

  async getTopProducts(limit = 5): Promise<Array<Product & { totalSold: number }>> {
    const result = await db.select({
      id: products.id,
      name: products.name,
      weight: products.weight,
      option: products.option,
      price: products.price,
      imageUrl: products.imageUrl,
      stock: products.stock,
      lowStockThreshold: products.lowStockThreshold,
      sku: products.sku,
      isActive: products.isActive,
      createdAt: products.createdAt,
      updatedAt: products.updatedAt,
      totalSold: sum(orderItems.quantity),
    })
    .from(products)
    .leftJoin(orderItems, eq(products.id, orderItems.productId))
    .groupBy(products.id)
    .orderBy(desc(sum(orderItems.quantity)))
    .limit(limit);

    return result.map(item => ({
      ...item,
      totalSold: Number(item.totalSold || 0),
    }));
  }

  async getCustomerStats(): Promise<{ totalCustomers: number; activeCustomers: number }> {
    const totalResult = await db.select({ count: count(users.id) })
      .from(users)
      .where(eq(users.role, 'customer'));

    const activeResult = await db.select({ count: count(users.id) })
      .from(users)
      .where(and(
        eq(users.role, 'customer'),
        eq(users.isActive, true)
      ));

    return {
      totalCustomers: Number(totalResult[0]?.count || 0),
      activeCustomers: Number(activeResult[0]?.count || 0),
    };
  }
}

export const storage = new DatabaseStorage();
